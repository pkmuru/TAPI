import { StreamMedia, VideoTile } from '@azure/communication-react';
import { DefaultButton, Persona, PersonaSize, Stack, Dialog, DialogType, DialogFooter } from '@fluentui/react';
import { CallEndIcon, CallIcon, CallVideoIcon, CallVideoOffIcon } from '@fluentui/react-northstar';
import { DefaultPalette, mergeStyles } from '@fluentui/react';
import useBoolean from './utils/useBoolean';
import { useLocation } from "react-router-dom";
import React from 'react'

interface IncomingCallModalProps extends IncomingCallToastProps {
  /** Text to the right of a Caller's Name */
  callerNameAlt?: string;
  /** A Caller's subtitle. Displayed right below the callers name */
  callerTitle?: string;
  /** Receiver's Name */
  localParticipantDisplayName?: string;
}

type IncomingCallToastProps = {
  /** Caller's Name */
  callerName?: string;
  /** Alert Text. For example "incoming video call..." */
  alertText?: string;
  /** Caller's Avatar/Profile Image */
  avatar?: string;

};

const palette = DefaultPalette;

const incomingCallModalContainerStyle = {
  borderRadius: '0.15rem',
};

const incomingCallModalLocalPreviewStyle = mergeStyles({
  background: palette.neutralLighterAlt,
  minWidth: '20rem',
  height: '10rem',
  margin: '1.5rem 0',
  borderRadius: '0.25rem',
  opacity: 0.95,
  '& video': {
    borderRadius: '0.25rem'
  }
});

interface IncomingCallModalProps extends IncomingCallToastProps {
  /** Text to the right of a Caller's Name */
  callerNameAlt?: string;
  /** A Caller's subtitle. Displayed right below the callers name */
  callerTitle?: string;
  /** Receiver's Name */
  localParticipantDisplayName?: string;
}

function useQuery() {
  const { search } = useLocation();

  return React.useMemo(() => new URLSearchParams(search), [search]);
}

const IncomingCallModal = (props: IncomingCallModalProps): JSX.Element => {
  let ipcRenderer: any;

  const {
    alertText,
    avatar,
    callerName,
    callerNameAlt,
    callerTitle,
    localParticipantDisplayName
  } = props;
  const palette = DefaultPalette;

  const dialogContentProps = { type: DialogType.normal, title: alertText ?? 'Incoming Call' };

  const callActionHandler = (answer: boolean) => {


    (async () => {
      if (ipcRenderer === undefined) {
        ipcRenderer = window.require("electron").ipcRenderer;
        console.log('init electron--1', ipcRenderer);
      }

      const result = await ipcRenderer.invoke('call-answer', { answer: answer });
    })();

  }

  const dragOptions = { toggle: true };
  return (
    <>
      <div >
        <Dialog
          hidden={false}
          onDismiss={() => { }}
          dialogContentProps={dialogContentProps}
          modalProps={{
            isBlocking: false,
            styles: { main: incomingCallModalContainerStyle },
          }}

        >
          <div style={{ width: '370px' }} />

          <Stack horizontal verticalAlign="center">
            <Stack horizontalAlign="start" style={{ marginRight: '0.5rem' }}>
              <Persona
                imageUrl={avatar}
                text={callerName}
                size={PersonaSize.size40}
                hidePersonaDetails={true}
                aria-label={callerName}
              />
            </Stack>
            <Stack grow={1} horizontalAlign="center" style={{ alignItems: 'flex-start' }}>
              <Stack style={{ fontSize: '0.875rem', color: palette.black, fontWeight: 'bold' }}>
                <span>
                  {callerName ?? 'No display name'}
                  {callerNameAlt ? (
                    <span style={{ opacity: 0.5, marginLeft: '0.2rem' }}> &bull; {callerNameAlt}</span>
                  ) : null}
                </span>
              </Stack>
              <Stack style={{ fontSize: '0.75rem', color: palette.neutralDark }}>
                <span>{callerTitle ?? ''}</span>
              </Stack>
            </Stack>
          </Stack>


          <DialogFooter>

            <DefaultButton
              onClick={() => { callActionHandler(true) }}
              text="Accept"
              style={{ background: palette.green, border: 'none' }}
            />

            <DefaultButton
              onClick={() => { callActionHandler(false) }}
              text="Decline"
              style={{ background: palette.red, border: 'none' }}
            />
          </DialogFooter>
        </Dialog>
      </div>
    </>
  );
};

export default IncomingCallModal;