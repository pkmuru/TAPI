import { BrowserRouter, Switch, Route, useHistory, useLocation, useParams } from 'react-router-dom';
import { AzureCommunicationTokenCredential } from '@azure/communication-common';
import {
  CallComposite,
  CallAdapter,
  createAzureCommunicationCallAdapter
} from '@azure/communication-react';
// MSAL imports
import { MsalProvider } from "@azure/msal-react";
import { IPublicClientApplication } from "@azure/msal-browser";
import { CustomNavigationClient } from "./utils/NavigationClient";
import React, { useEffect, useMemo, useState, useContext } from 'react';
import { MyReferenceDataContextProvider } from './MyReferenceDataContext';
import IncomingCallModal from './IncomingCallModal';
import LoginView from './LoginView';
import MakeCallView from './MakeCallView';
const queryString = require('query-string');

type AppProps = {
  pca: IPublicClientApplication
};


function App({ pca }: AppProps): JSX.Element {


  const history = useHistory();
  const navigationClient = new CustomNavigationClient(history);
  pca.setNavigationClient(navigationClient);

  return (
    <MsalProvider instance={pca}>
      <MyReferenceDataContextProvider >
        <Pages />
      </MyReferenceDataContextProvider>
    </MsalProvider>
  );
}

function Pages() {



  // eslint-disable-next-line no-restricted-globals
  const parsed = queryString.parse(location.search);
  console.log('location-->', parsed);

  let callerName = 'Unknown';
  let callerNumber = 'Unknown';

  if (parsed && parsed.name) {
    callerName = parsed.name;
  }


  if (parsed && parsed.number) {
    callerNumber = parsed.number;
  }

  return (

    <BrowserRouter>
      <Switch>
        <Route path="/notification">
          <IncomingCallModal alertText='Incoming Smart Call Alert' callerName={callerName} callerNameAlt='1st' callerTitle={callerNumber} />
        </Route>
        <Route path="/makeCall">
          <MakeCallView />
        </Route>
        <Route path="/">
          <LoginView />
        </Route>
        <Route path="/login">
          <LoginView />
        </Route>

      </Switch>
    </BrowserRouter>

  )
}

function Profile() {
  return <div>Profile</div>;
}

export default App;
