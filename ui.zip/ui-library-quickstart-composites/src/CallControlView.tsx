import { CallParticipantListParticipant, FluentThemeProvider, ParticipantList, EndCallButton, MicrophoneButton } from '@azure/communication-react';
import { Call, CallAgent, CallClient, StartCallOptions, RemoteParticipant } from '@azure/communication-calling';
import { CallEnd20Filled, MicOff20Filled } from '@fluentui/react-icons';
import { Button, Flex, TextArea, Segment, List, Image } from '@fluentui/react-northstar'
import { Stack } from '@fluentui/react';
import React, { useState, useEffect } from 'react';
import { PhoneNumberKind } from '@azure/communication-common';

interface CallControlProps {
    call: Call
}
const CallControlView = (props: CallControlProps): JSX.Element => {

    const {
        call
    } = props;

    const [participants, setParticipants] = useState<CallParticipantListParticipant[]>([])

    useEffect(() => {
        console.log(call.remoteParticipants);
        console.log(call.direction);
        console.log(call.callerInfo);

        let participants: CallParticipantListParticipant[] = [];

        call.remoteParticipants.forEach((participant: RemoteParticipant) => {

            console.log(participant);

            let phoneNumber = participant.identifier.kind;


            let p: CallParticipantListParticipant = {
                userId: participant.identifier.kind,
                displayName: participant.displayName,
                state: 'Connected',
                isMuted: participant.isMuted,
                isRemovable: false
            };

            participants.push(p);
        });

        setParticipants(participants);

    }, [])

    const endCallHandler = () => {
        call.hangUp();
    }




    return (
        <FluentThemeProvider>
            <Stack>
                <div style={{ fontSize: '1.5rem', marginBottom: '1rem', fontFamily: 'Segoe UI' }}>Call Participants</div>
                {participants && (<ParticipantList participants={participants} myUserId={'user1'} />)}
                <Flex gap="gap.small" padding="padding.medium">
                    <Flex.Item size="size.quarter">
                        <EndCallButton showLabel={true} onRenderIcon={() => <CallEnd20Filled primaryFill="currentColor" key={'hangupBtnIconKey'} />} onClick={() => { endCallHandler() }} />
                    </Flex.Item>
                    <Flex.Item size="size.quarter">
                        <MicrophoneButton showLabel={true} checked={true} onRenderIcon={() => <MicOff20Filled primaryFill="currentColor" key={'hangupBtnIconKey'} />} />
                    </Flex.Item>
                </Flex>
                <div>State: {call.state}</div>
                <div>Direction: {call.direction}</div>                
            </Stack>
        </FluentThemeProvider>
    );
};

export default CallControlView;