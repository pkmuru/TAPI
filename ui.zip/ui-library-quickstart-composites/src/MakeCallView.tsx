import { AzureCommunicationTokenCredential } from '@azure/communication-common';
import { v4 as createGUID } from 'uuid';
import {
    FluentThemeProvider,
    DEFAULT_COMPONENT_ICONS,
    CallClientProvider,
    CallAgentProvider,
    CallProvider,
    createStatefulCallClient,
    StatefulCallClient,
    ControlBar,
    CallParticipantListParticipant,
    CameraButton,
    EndCallButton,
    MicrophoneButton,
    DevicesButton,
    ParticipantsButton,
    ScreenShareButton,
    CallAdapter,
    CallComposite,
    CallCompositeOptions,
    CompositeLocale,
    createAzureCommunicationCallAdapter
} from '@azure/communication-react';
import { Call, CallAgent, CallClient, StartCallOptions } from '@azure/communication-calling';
import { Button, Flex, TextArea } from '@fluentui/react-northstar'
import React, { useEffect, useMemo, useState, useContext } from 'react';
import { DefaultButton, IContextualMenuProps } from '@fluentui/react';
import { ReferenceDataContext } from './MyReferenceDataContext';
import { CallEnd20Filled } from '@fluentui/react-icons';
import CallControlView from './CallControlView';



export default function MakeCallView(): JSX.Element {

    const [statefulCallClient, setStatefulCallClient] = useState<StatefulCallClient>()
    const [callAgent, setCallAgent] = useState<CallAgent>()
    const [call, setCall] = useState<Call>()
    const [callID, setCallID] = useState<any>()
    const [callState, setCallState] = useState<any>()
    const [adapter, setAdapter] = useState<CallAdapter>();


    const initAcsUser = () => {
        console.log('setStatefulCallClient');

        if (callAgent === undefined) {
            (async () => {

                fetch('http://localhost:8080/token?scope=voip').then((response) => {
                    response.json().then((data) => {
                        console.log('ACS Token', data);
                        (async () => {
                            const tokenCredential = new AzureCommunicationTokenCredential(data.token);
                            const callclient = new CallClient();
                            let callAgent2 = await callclient.createCallAgent(tokenCredential);
                            setCallAgent(callAgent2);
                        })();
                    })
                });
            })();
        }
    };


    const makeCall = (phone: string) => {
        if (callAgent) {
            const pstnCallee = { phoneNumber: phone }
            const alternateCallerId = { phoneNumber: '+16093083754' };
            //+1 501-232-8904
            //pstn acs '+16093083754' 
            //caller id 15012328904
            //const phoneToCall = '+12013527864';            
            const groupId = createGUID();



            const oneToOneCall = callAgent.startCall([pstnCallee], { alternateCallerId });
            console.log(oneToOneCall);
            setCall(oneToOneCall);
            setCallID(oneToOneCall.id);
            setCallState(oneToOneCall.state);
            oneToOneCall.on('stateChanged', (): void => {
                console.log('state--->', oneToOneCall.state);
                setCall(oneToOneCall);
                setCallID(oneToOneCall.id);
                setCallState(oneToOneCall.state);
            });

        }
    }

    useEffect(() => {


    }, [])







    const onMuteAll = (): void => {
        // your implementation to mute all participants
    };


    return (
        <>
            <FluentThemeProvider>
                <div>
                    <Button onClick={() => { initAcsUser() }}>Init call agent - ACS User</Button>

                    {callAgent && (
                        <div>
                            <DefaultButton text='Make call' onClick={() => {
                                makeCall('+12016917231');
                            }} />
                        </div>
                    )}

                    {call && (
                        <div>
                            <CallControlView call={call} />
                            <div>x{call.state}</div>
                            <div>x{call.direction}</div>
                        </div>
                    )}

                    <div>x{callID}</div>
                    <div>x{callState}</div>
                </div>



            </FluentThemeProvider>
        </>
    );
}