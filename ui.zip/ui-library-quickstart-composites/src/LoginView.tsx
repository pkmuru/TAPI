import { useMsal } from "@azure/msal-react";
import { useEffect, useState, useContext } from "react";
import { loginRequest } from "./authConfig";
import { Button, Flex, TextArea, Segment, List, Image } from '@fluentui/react-northstar'
import {
    useHistory
} from "react-router-dom";
import { ReferenceDataContext } from './MyReferenceDataContext';
import CallAgentView from './CallAgentView';
import MyContactListView from './MyContactListView';

const LoginView = (): JSX.Element => {

    const { instance, accounts } = useMsal();
    const history = useHistory();
    const { query, setQuery } = useContext(ReferenceDataContext);


    useEffect(() => {
        console.log(accounts.length);
        if (accounts.length === 0) {
            instance.loginRedirect(loginRequest);
        } else {
            console.log(accounts[0]);
        }
    });

    const handleLogin = () => {
        instance.loginRedirect(loginRequest);
    }

    const handleAcsToken = () => {
        instance.acquireTokenSilent({ ...loginRequest, account: accounts[0] }).then((response) => {
            console.log(response);

            const requestOptions = {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ token: response.accessToken })
            };

            fetch('http://localhost:8080/teamsToken', requestOptions).then((response) => {
                response.json().then((data) => {
                    console.log('ACS Token', data.token);
                    setQuery(data.token);
                })
            });

        });
    }


    return (

        <div>


            <>
                <Flex gap="gap.small" padding="padding.medium">
                    <Flex.Item size="size.quarter">
                        <Button onClick={() => handleLogin()} primary >
                            Login to AAD
                        </Button>
                    </Flex.Item>

                    <Flex.Item size="size.quarter">
                        <Button onClick={() => handleAcsToken()} primary>
                            Get token from ACS
                        </Button>
                    </Flex.Item>


                </Flex>
                <Flex.Item size="size.quarter">
                    <CallAgentView />
                </Flex.Item>




            </>

        </div>
    )
}

export default LoginView;