import {
    CallParticipantListParticipant,
    FluentThemeProvider,
    ParticipantList,
    ParticipantItem,
    ParticipantListParticipant
} from '@azure/communication-react';
import { Button, CommandButton, Icon, Label, Link, IContextualMenuItem, PersonaPresence } from '@fluentui/react';
import React, { useState } from 'react';
import { IPersonaSharedProps, IPersonaProps, Persona, PersonaInitialsColor, PersonaSize } from '@fluentui/react/lib/Persona';
import { Stack, IStackStyles, IStackTokens } from '@fluentui/react/lib/Stack';


type MyContactListViewProps = {
    onMakeCall: (phone: string) => void,
};

const participants: IPersonaSharedProps[] =
    [
    {
        secondaryText: '+1',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'Maor Sharett',
        imageInitials: 'MS',
    },
    {
        secondaryText: '+1 201 691-7231',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'John Doe',
        imageInitials: 'JD',
    }, {
        secondaryText: '+860 888-7753',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'Bollu, Ravi',
        imageInitials: 'BR',
    }, {
        secondaryText: '+91 2067422311',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'Bhat, Nagaraj',
        imageInitials: 'BN',
    }, {
        secondaryText: '+41779520772',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'Dhamre, Sagar',
        imageInitials: 'SD',
    }, {
        secondaryText: '+1 201 352-7864',
        tertiaryText: 'In a meeting',
        optionalText: 'Available at 4:00pm',
        text: 'Padikkasu, Muruganantham',
        imageInitials: 'PM',
    }
    ];



const MyContactListView = (props: MyContactListViewProps): JSX.Element => {

    const themedMediumStackTokens: IStackTokens = {
        childrenGap: 'm',
        padding: 'm',
    };
    let onMakeCall = props.onMakeCall;

    const listItems = participants.map((participant) => {
        return <Persona {...participant} initialsColor={PersonaInitialsColor.lightBlue} size={PersonaSize.size56} onRenderSecondaryText={(props?: IPersonaSharedProps) => (
            <CommandButton
                text={props && props.secondaryText}
                menuProps={{
                    items: [
                        {
                            key: "1", text: "Call", onClick: () => {
                                if (props && props.secondaryText) {
                                    onMakeCall(props.secondaryText);
                                }
                            }
                        },
                    ]
                }}
            >
            </CommandButton>
        )} />
    });

    return (
        <FluentThemeProvider>
            <Stack tokens={themedMediumStackTokens}>
                <div style={{ fontSize: '1.5rem', marginBottom: '1rem', fontFamily: 'Segoe UI' }}>My Contacts</div>
                {listItems}
            </Stack>
        </FluentThemeProvider>
    );
};

export default MyContactListView;