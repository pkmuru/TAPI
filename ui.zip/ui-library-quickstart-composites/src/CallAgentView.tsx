import { AzureCommunicationTokenCredential } from '@azure/communication-common';
import { v4 as createGUID } from 'uuid';
import {
    FluentThemeProvider,
    DEFAULT_COMPONENT_ICONS,
    CallClientProvider,
    CallAgentProvider,
    CallProvider,
    createStatefulCallClient,
    StatefulCallClient,
    ControlBar,
    CallParticipantListParticipant,
    CameraButton,
    EndCallButton,
    MicrophoneButton,
    DevicesButton,
    ParticipantsButton,
    ScreenShareButton,
    CallAdapter,
    CallComposite,
    CallCompositeOptions,
    CompositeLocale,
    createAzureCommunicationCallAdapter
} from '@azure/communication-react';
import { Call, CallAgent, CallClient, StartCallOptions } from '@azure/communication-calling';
import React, { useEffect, useMemo, useState, useContext } from 'react';
import { DefaultButton, IContextualMenuProps } from '@fluentui/react';
import { ReferenceDataContext } from './MyReferenceDataContext';
import { CallEnd20Filled } from '@fluentui/react-icons';
import CallControlView from './CallControlView';
import MyContactListView from './MyContactListView';
import { Button, Flex, TextArea, Segment, List, Image } from '@fluentui/react-northstar'


declare global {
    interface Window {
        require: any;
    }
}


export default function CallAgentView(): JSX.Element {
    const { query, setQuery } = useContext(ReferenceDataContext);
    let ipcRenderer: any;
    //const userId = '<User Id associated to the token>';
    //const userAccessToken = 'eyJhbGciOiJSUzI1NiIsImtpZCI6IjEwNCIsIng1dCI6IlJDM0NPdTV6UENIWlVKaVBlclM0SUl4Szh3ZyIsInR5cCI6IkpXVCJ9.eyJza3lwZWlkIjoib3JnaWQ6YjIzMGZhM2EtYjczYi00M2QyLWI5NjMtZDA5YzRhZjFkYzQ0Iiwic2NwIjoxMDI0LCJjc2kiOiIxNjQ4MDQ3NDEwIiwiZXhwIjoxNjQ4MDUxNzEwLCJ0aWQiOiI2ZWI0MjdiZi0yYTY4LTQwNjctOTI3Mi1mZTVkOTU1MTNhMmMiLCJhY3NTY29wZSI6InZvaXAiLCJyZXNvdXJjZUlkIjoiNGYwMDVhYmYtMTc2Ni00YmY5LThiYTMtMjhhZDE5ZmE5MGY1IiwiaWF0IjoxNjQ4MDQ3NzEwfQ.kkeNJY3N8uHZSHrK8zuijUAXmlMTPaoIiMD-o4DyovBY7027bg9Nr5M7M0lLsZYK5VLaHLdkKWuEcAIwiv05RxAU0SvrRlnZWezA1omCxOH9JUSmjbiLjunIHJ3jr-iRRELg0Y23f6OARMGreHaK4ZFpquMOogxlX2iz7c94_iSyk-71NiH1Cx4GVLZeL9dnGrLtICSaSJQy0Hl5tuxXpPuN7S7i618wHFrcSXRkhVSWjdWV5EI2gbk0YDUqdBKk7ZTIo8DcJx40GbgEfKz-4WQGIyPJ1MxY2DU2jsrtyqX4p_g718dF51M9j_BOwmjstjPHJp41Ja60K3fPqjM3Kw';
    //const groupId = '<Generated GUID groupd id>';
    //const displayName = '';

    const [statefulCallClient, setStatefulCallClient] = useState<StatefulCallClient>()
    const [callAgent, setCallAgent] = useState<CallAgent>()
    const [call, setCall] = useState<Call>()
    const [adapter, setAdapter] = useState<CallAdapter>();
    const [callID, setCallID] = useState<any>()
    const [callState, setCallState] = useState<any>()

    useEffect(() => {

        console.log('init electron', ipcRenderer);

        if (ipcRenderer === undefined) {
            ipcRenderer = window.require("electron").ipcRenderer;
            console.log('init electron--1', ipcRenderer);
        }


        // Listen for the event
        ipcRenderer.on('my-invokable-ipc', (event: any, arg: any) => {
            console.log('message from electron', arg);
            //
        });        // Clean the listener after the component is dismounted

    }, []);

    const initAcs = () => {
        console.log('setStatefulCallClient');

        if (callAgent === undefined) {
            (async () => {
                const tokenCredential = new AzureCommunicationTokenCredential(query);

                const groupId = await createGUID();

                /*     let adapter1 = await createAzureCommunicationCallAdapter({
                        userId: { communicationUserId: groupId },
                        displayName: '', // Max 256 Characters
                        credential: new AzureCommunicationTokenCredential('eyJhbGciOiJSUzI1NiIsImtpZCI6IjEwNCIsIng1dCI6IlJDM0NPdTV6UENIWlVKaVBlclM0SUl4Szh3ZyIsInR5cCI6IkpXVCJ9.eyJza3lwZWlkIjoib3JnaWQ6YjIzMGZhM2EtYjczYi00M2QyLWI5NjMtZDA5YzRhZjFkYzQ0Iiwic2NwIjoxMDI0LCJjc2kiOiIxNjQ4MDU1Nzc0IiwiZXhwIjoxNjQ4MDYxMTA3LCJ0aWQiOiI2ZWI0MjdiZi0yYTY4LTQwNjctOTI3Mi1mZTVkOTU1MTNhMmMiLCJhY3NTY29wZSI6InZvaXAiLCJyZXNvdXJjZUlkIjoiNGYwMDVhYmYtMTc2Ni00YmY5LThiYTMtMjhhZDE5ZmE5MGY1IiwiaWF0IjoxNjQ4MDYwNzg5fQ.ze6sP1N1W0akYPLe0MJ3OiwP1QN9r2_0JBrHvIncqWuq0SYk62pmtyHUpX5RpeX5-Sxt3HNbTvhwVTOiJSHKFXY12Znq0j81CYTX31scG2lkeCK86h7cs8G2lo7Ey9rZdyd6WFq_w3t6RCYChlLD_9BQZ-Dhqq8C7i9rzAlFLVU6jNa8h1-jfG97N2a0wS34q42yoYlHsrqBintVWOXOk2zFs5tkvmoRKD6OMg4plIgLKeWnt6Q-Y8ZjlAMIGjUzD6MvDJ5IjlCqd4jiREMwexiLoqYcPUPeZPxISzNZnQ_1DrJ5QC02sV2zKjrRA2fov-W7BRd0vpp-IicAXvUgCw'),
                        locator: { groupId: 'ignore' }
                    });
    
                    setAdapter(adapter1); */

                const callclient = new CallClient();
                let callAgent2 = await callclient.createCallAgent(tokenCredential);
                setCallAgent(callAgent2);
                let deviceManager = await callclient.getDeviceManager();
                await deviceManager.askDevicePermission({ audio: true, video: false });


                callAgent2.on('incomingCall', async (args) => {

                    try {
                        let incomingCall = args.incomingCall;
                        console.log('---incoming----', incomingCall.id);
                        console.log('sending to electron');



                        (async () => {
                            if (ipcRenderer === undefined) {
                                ipcRenderer = window.require("electron").ipcRenderer;
                                console.log('init electron--1', ipcRenderer);
                            }

                            const callerInfo = incomingCall.callerInfo;
                            const callerIdentifier:any = incomingCall.callerInfo.identifier;


                            const result = await ipcRenderer.invoke('incoming-call-alert', { call: 'incomingCall' + incomingCall.id, name: callerInfo.displayName, number: callerIdentifier?.phoneNumber });
                            ipcRenderer.removeAllListeners();

                            ipcRenderer.on('call-action', (event: any, arg: any) => {
                                console.log('reply from call answer for ' + incomingCall.id, arg);
                                if (arg[0].answer) {
                                    (async () => {
                                        let callIn = await incomingCall.accept();
                                        console.log('call answered, active call is ' + incomingCall.id);
                                        setCall(callIn);

                                        console.log('callIn', callIn);

                                        callIn.on('stateChanged', (): void => {
                                            console.log('state--->', callIn.state);
                                            setCall(callIn);
                                            setCallID(callIn.id);
                                            setCallState(callIn.state);
                                        });

                                    })();
                                } else {
                                    incomingCall.reject();
                                }
                            });

                        })();

                        console.log(incomingCall);
                    } catch (error) {

                    }
                });

            })();
        }
    };

    const makeCall = (phoneToCall: string) => {
        //const phoneToCall = '+15012383175';
        const pstnCallee = { phoneNumber: phoneToCall }
        //const alternateCallerId = { alternateCallerId: '+15012328904' };
        //caller id 15012328904

        const groupId = createGUID();

        const callAgent2: any = callAgent;

        let outCall = callAgent2.startCall([pstnCallee], { threadId: groupId });


        setCall(outCall);
        console.log('outCall', outCall);
        outCall.on('stateChanged', (): void => {
            console.log('state--->', outCall.state);
            setCall(outCall);
            setCallID(outCall.id);
            setCallState(outCall.state);
        });
    }


    return (
        <>
            <FluentThemeProvider>
                <div>
                    <Button onClick={() => { initAcs() }} primary>Init Call Agent</Button>

                    <Flex
                        gap="gap.small"
                        padding="padding.medium"
                        style={{
                            minHeight: 200,
                        }}
                    >

                        <Flex.Item size="size.half">
                            <Segment content={call && (
                                <div>
                                    <div>
                                        <CallControlView call={call} />
                                    </div>


                                </div>
                            )} />
                        </Flex.Item>

                        <Flex.Item size="size.half">
                            <Segment content={<MyContactListView onMakeCall={(phone) => {
                                makeCall(phone);
                            }} />} />
                        </Flex.Item>


                    </Flex>



                    {callAgent && (
                        <div>Call agent is ready                        </div>

                    )}




                </div>



            </FluentThemeProvider>
        </>
    );
}