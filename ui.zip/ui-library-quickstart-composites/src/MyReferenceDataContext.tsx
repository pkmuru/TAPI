import React, { createContext, useReducer, useState } from "react";

interface SharedData {
  acToken: string,
  currentPage: string
}

const ReferenceDataContext = createContext({
  query: 'test',
  setQuery: (query: string) => { }
});

const MyReferenceDataContextProvider = (props: { children: React.ReactNode; }) => {
  const [query, setQuery] = useState("test1")
  return (
    <ReferenceDataContext.Provider value={{ query, setQuery }}>
      {props.children}
    </ReferenceDataContext.Provider>
  );
};

export { ReferenceDataContext, MyReferenceDataContextProvider };