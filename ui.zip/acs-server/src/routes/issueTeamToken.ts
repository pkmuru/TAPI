// Copyright (c) Microsoft Corporation.
// Licensed under the MIT license.

import { CommunicationUserToken, TokenScope, CommunicationIdentityClient, CommunicationAccessToken } from '@azure/communication-identity';
import * as express from 'express';
import { createUserAndToken } from '../lib/identityClient';

const router = express.Router();

/**
 * handleUserTokenRequest will return a default scoped token if no scopes are provided.
 * @param requestedScope [optional] string from the request, this should be a comma seperated list of scopes.
 */
const handleUserTokenRequest = async (token: string): Promise<CommunicationAccessToken> => {
  console.log('Token request' , token);
  const connectionString = "endpoint=https://sc-demo-acs-service.communication.azure.com/;accesskey=cJRi0BT5y/yP2jeplA0O/hg4Qvh3FA6TLLvO9SXtmluDHclxdOCHV4/uJVFivwq+touQFz1usctnab5eH4/AXA==";
  const identityClient = new CommunicationIdentityClient(connectionString);
  return await identityClient.getTokenForTeamsUser(token);
};

/**
 * route: /token/
 *
 * purpose: To get Azure Communication Services token with the given scope.
 *
 * @param scope: scope for the token as string
 *
 * @returns The token as string
 *
 * @remarks
 * By default the get and post routes will return a token with scopes ['chat', 'voip'].
 * Optionally ?scope can be passed in containing scopes seperated by comma
 * e.g. ?scope=chat,voip
 *
 */

router.post('/', async (req, res, next) => res.send(await handleUserTokenRequest((req.body.token as string) ?? '')));

export default router;
